<?php
if(version_compare(PHP_VERSION, '7.2.0', '>=')) {
    error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
}

use Illuminate\Support\Facades\Route;
use App\Events\BetUpdated;
use Pusher\Pusher;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


// //Clear Cache facade value:
// Route::get('/clear-cache', function() {
//     $exitCode = Artisan::call('cache:clear');
//     return '<h1>Cache facade value cleared</h1>';
// });

// //Reoptimized class loader:
// Route::get('/optimize', function() {
//     $exitCode = Artisan::call('optimize');
//     return '<h1>Reoptimized class loader</h1>';
// });

// //Route cache:
// Route::get('/route-cache', function() {
//     $exitCode = Artisan::call('route:cache');
//     return '<h1>Routes cached</h1>';
// });

// //Clear Route cache:
// Route::get('/route-clear', function() {
//     $exitCode = Artisan::call('route:clear');
//     return '<h1>Route cache cleared</h1>';
// });

// //Clear View cache:
// Route::get('/view-clear', function() {
//     $exitCode = Artisan::call('view:clear');
//     return '<h1>View cache cleared</h1>';
// });

// //Clear Config cache:
// Route::get('/config-cache', function() {
//     $exitCode = Artisan::call('config:cache');
//     return '<h1>Clear Config cleared</h1>';
// });



//Live routes
Route::get('/getCategory',[
    'uses'  => 'BroadCastController@getCategory',
    'as'    => 'getCategory'
]);
Route::get('/broadcast/{catId}',[
    'uses'  => 'BroadCastController@broadcast',
    'as'    => 'broadcast'
]);
Route::get('/broadcastMain',[
    'uses'  => 'BroadCastController@broadcastMain',
    'as'    => 'broadcastMain'
]);
Route::get('/broadcastCategory',[
    'uses'  => 'BroadCastController@broadcastCategory',
    'as'    => 'broadcastCategory'
]);
//Question hide show leader routes
Route::get('/fqHideShowLeader/{tournamentId}/{matchId}',[
    'uses'  => 'EventController@fqHideShowLeader',
    'as'    => 'fqHideShowLeader'
]);
Route::get('/cqHideShowLeader/{tournamentId}/{matchId}',[
    'uses'  => 'EventController@cqHideShowLeader',
    'as'    => 'cqHideShowLeader'
]);

//Question update leader
Route::get('/cqUpdateLeader/{cqId}/{tournamentId}/{matchId}',[
    'uses'  => 'EventController@cqUpdateLeader',
    'as'    => 'cqUpdateLeader'
]);
//Live match hide/show routes
Route::get('control-panel/admin/matchStatus/{id}/{tournament}/{status}',[
    'uses'  => 'EventController@matchStatus',
    'as'    => 'matchStatus'
]);
Route::get('/matchStatusLeader/{matchId}/{tournamentId}',[
    'uses'  => 'EventController@matchStatusLeader',
    'as'    => 'matchStatusLeader'
]);
//Live Bet show/hide routes
Route::get('control-panel/admin/allBetHideShow/{id}/{tournament}/{status}',[
    'uses'  => 'EventController@allBetHideShow',
    'as'    => 'allBetHideShow'
]);
Route::get('/allBetHideShowStatusLeader/{matchId}/{tournamentId}',[
    'uses'  => 'EventController@allBetHideShowStatusLeader',
    'as'    => 'allBetHideShowStatusLeader'
]);
//Live Bet On/Off routes
Route::get('control-panel/admin/liveBetOnOff/{id}/{tournament}/{status}',[
    'uses'  => 'EventController@liveBetOnOff',
    'as'    => 'liveBetOnOff'
]);
Route::get('/liveBetOnOffStatusLeader/{matchId}/{tournamentId}',[
    'uses'  => 'EventController@liveBetOnOffStatusLeader',
    'as'    => 'liveBetOnOffStatusLeader'
]);
//All Bet show/hide routes
Route::get('control-panel/admin/allBetOnOff/{id}/{tournament}/{status}',[
    'uses'  => 'EventController@allBetOnOff',
    'as'    => 'allBetOnOff'
]);
Route::get('/allBetOnOffStatusLeader/{matchId}/{tournamentId}',[
    'uses'  => 'EventController@allBetOnOffStatusLeader',
    'as'    => 'allBetOnOffStatusLeader'
]);
//Betting turn on/off status
Route::get('control-panel/admin/fqStatusChange/{id}/{matchId}/{tournament}/{status}',[
    'uses'  => 'EventController@fqStatusChange',
    'as'    => 'fqStatusChange'
]);

Route::get('control-panel/admin/cqStatusChange/{id}/{matchId}/{tournament}/{status}',[
    'uses'  => 'EventController@cqStatusChange',
    'as'    => 'cqStatusChange'
]);
//Hide question status
Route::get('control-panel/admin/fqHideShow/{id}/{matchId}/{tournament}/{status}',[
    'uses'  => 'EventController@fqHideShow',
    'as'    => 'fqHideShow'
]);

Route::get('control-panel/admin/cqHideShow/{id}/{matchId}/{tournament}/{status}',[
    'uses'  => 'EventController@cqHideShow',
    'as'    => 'cqHideShow'
]);
//Match finish from live match
Route::get('control-panel/admin/matchFinish/{tournament}/{id}',[
    'uses'  => 'EventController@matchFinish',
    'as'    => 'matchFinish'
]);
Route::get('control-panel/admin/matchHide/{tournament}/{id}',[
    'uses'  => 'EventController@matchHide',
    'as'    => 'matchHide'
]);
 Route::get('control-panel/admin/hideUserPage/{tournament}/{id}',[
     'uses'  => 'EventController@hideUserPage',
     'as'    => 'hideUserPage'
 ]);
//Update question details
 
Route::post('control-panel/admin/fqUpdate',[
    'uses'  => 'EventController@fQupdate',
    'as'    => 'fQupdate'
]);
Route::get('/fqUpdateLeader/{fqId}/{tournamentId}/{matchId}',[
    'uses'  => 'EventController@fqUpdateLeader',
    'as'    => 'fqUpdateLeader'
]);

Route::post('control-panel/admin/cqUpdate',[
   'uses'  => 'EventController@cQupdate',
   'as'    => 'cQupdate'
]);

//Publish single result
Route::get('control-panel/admin/publishSingleResult/{team}/{id}/{matchId}/{tournament}',[
    'uses'  => 'EventController@publishSingleResult',
    'as'    => 'publishSingleResult'
]);
//Unpublish fixed question
Route::get('control-panel/admin/fqUnpublish/{id}/{matchId}/{tournament}',[
    'uses'  => 'EventController@fqUnpublish',
    'as'    => 'fqUnpublish'
]);
Route::get('control-panel/admin/pertialPublish/{id}/{matchId}/{tournament}/{quesId}/{betOn}/{pertialAmount}',[
    'uses'  => 'EventController@pertialPublish',
    'as'    => 'pertialPublish'
]);
//Unpublish custom answer
Route::get('control-panel/admin/cqUnpublish/{id}/{matchId}/{tournament}',[
    'uses'  => 'EventController@cqUnpublish',
    'as'    => 'cqUnpublish'
]);

Route::get('control-panel/admin/publishCQResult/{answer}/{id}/{matchId}/{tournament}',[
    'uses'  => 'EventController@publishCQResult',
    'as'    => 'publishCQResult'
]);
 
Route::post('dashboard/cqBetPlace',[
    'uses'  => 'UserPanelController@cqBetPlace',
    'as'    => 'cqBetPlace'
]);
 
Route::post('dashboard/fqBetPlace',[
    'uses'  => 'UserPanelController@fqBetPlace',
    'as'    => 'fqBetPlace'
]);
 
Route::get('fqsendLiveRoom/{id}/{matchId}/{tournament}',[
    'uses'  => 'EventController@fqsendLiveRoom',
    'as'    => 'fqsendLiveRoom'
]);
 

//Manual Routes
Route::get('/',[
    'uses'  =>'FrontController@frontHome',
    'as'    => 'frontHome'
]);

Route::get('/advanceBet',[
    'uses'  =>'FrontController@advanceBet',
    'as'    => 'advanceBet'
]);

//user login/registration system
Route::get('user-register',[
    'uses'  => 'FrontController@userRegister',
    'as'    => 'userRegister'
]);
 
Route::post('confirm-user-register',[
    'uses'  => 'FrontController@confirmRegister',
    'as'    => 'confirmRegister'
]);

Route::get('user-login',[
    'uses'  => 'FrontController@userLogin',
    'as'    => 'userLogin'
]);

Route::post('confirm-user-login',[
    'uses'  => 'FrontController@confirmLogin',
    'as'    => 'confirmLogin'
]);
 
Route::post('user-logout',[
    'uses'  => 'FrontController@userlogout',
    'as'    => 'userlogout'
]);
 
Route::post('admin-logout',[
    'uses'  => 'FrontController@adminLogout',
    'as'    => 'adminLogout'
]);
 
Route::post('club-logout',[
    'uses'  => 'FrontController@clubLogout',
    'as'    => 'clubLogout'
]);
 
 //User Dashboard Routes
 
Route::get('dashboard',[
    'uses'  => 'UserViewController@userdash',
    'as'    => 'userdash'
]);
 
Route::get('dashboard/profile',[
    'uses'  => 'UserViewController@userprofile',
    'as'    => 'userprofile'
]);

Route::post('dashboard/update-profile',[
    'uses'  => 'UserPanelController@profileupdate',
    'as'    => 'profileupdate'
]);
 
//Change password
Route::get('dashboard/changeMyPass',[
    'uses'  => 'UserViewController@changeMyPass',
    'as'    => 'changeMyPass'
]);

Route::post('dashboard/updateMyPass',[
    'uses'  => 'UserPanelController@updateMyPass',
    'as'    => 'updateMyPass'
]);
 
//Change club
Route::get('dashboard/changeMyClub',[
    'uses'  => 'UserViewController@changeMyClub',
    'as'    => 'changeMyClub'
]);

Route::post('dashboard/updateMyClub',[
    'uses'  => 'UserPanelController@updateMyClub',
    'as'    => 'updateMyClub'
]);
 
//Betting History routes
Route::get('dashboard/betHistory',[
    'uses'  => 'UserViewController@betHistory',
    'as'    => 'betHistory'
]);
 
Route::get('dashboard/myFollowerList',[
    'uses'  => 'UserViewController@myFollowerList',
    'as'    => 'myFollowerList'
]);
 
//account statement routes
Route::get('dashboard/customerAccountStmt',[
    'uses'  => 'UserViewController@customerAccountStmt',
    'as'    => 'customerAccountStmt'
]);
 //Deposit routes
 Route::get('dashboard/makeDeposit',[
     'uses'  => 'UserViewController@makeDeposit',
     'as'    => 'makeDeposit'
 ]);
 
Route::get('dashboard/deposit/hisroty',[
    'uses'  => 'UserViewController@depositHistory',
    'as'    => 'depositHistory'
]);

Route::post('dashboard/depositRequest',[
    'uses'  => 'UserPanelController@depositRequest',
    'as'    => 'depositRequest'
]);
 
//Withdrawal routes
Route::get('dashboard/makeWithdraw',[
    'uses'  => 'UserViewController@makeWithdraw',
    'as'    => 'makeWithdraw'
]);
 
Route::get('dashboard/withdraw/hisroty',[
    'uses'  => 'UserViewController@withdrawHistory',
    'as'    => 'withdrawHistory'
]);

Route::post('dashboard/withdrawRequest',[
    'uses'  => 'UserPanelController@withdrawRequest',
    'as'    => 'withdrawRequest'
]);

Route::get('dashboard/refundWithdraw/{id}',[
    'uses'  => 'UserPanelController@refundWithdraw',
    'as'    => 'refundWithdraw'
]);
 
//C2C Transfer routes
Route::get('dashboard/makeC2CTransfer',[
    'uses'  => 'UserViewController@makeC2CTransfer',
    'as'    => 'makeC2CTransfer'
]);
 
Route::get('dashboard/c2c/transfer-history',[
    'uses'  => 'UserViewController@C2CTransferHistory',
    'as'    => 'C2CTransferHistory'
]);

Route::post('dashboard/C2CTransferRequest',[
    'uses'  => 'UserPanelController@C2CTransferRequest',
    'as'    => 'C2CTransferRequest'
]);

Route::get('dashboard/c2c/receiving-history',[
    'uses'  => 'UserViewController@C2CReceivingHistory',
    'as'    => 'C2CReceivingHistory'
]);
 
 
 //club management routes
Route::get('club/login',[
    'uses'  => 'FrontController@clubLogin',
    'as'    => 'clubLogin'
]);
 
Route::post('club/confirmClubLogin',[
    'uses'  => 'FrontController@confirmClubLogin',
    'as'    => 'confirmClubLogin'
]);
 
//Withdrawal routes
Route::get('club/home',[
    'uses'  => 'ClubController@home',
    'as'    => 'clubHome'
]);
 
Route::get('club/makeClubWithdraw',[
    'uses'  => 'ClubController@makeClubWithdraw',
    'as'    => 'makeClubWithdraw'
]);

Route::post('club/submitClubWithdraw',[
    'uses'  => 'ClubController@submitClubWithdraw',
    'as'    => 'submitClubWithdraw'
]);
 
Route::get('club/clubWithdrawHistory/{club}',[
    'uses'  => 'ClubController@clubWithdrawHistory',
    'as'    => 'clubWithdrawHistory'
]);
//Club Statement
Route::get('club/statement/{club}',[
    'uses'  => 'ClubController@clubStatement',
    'as'    => 'clubStatement'
]);
 
Route::get('club/follower/{clubid}',[
    'uses'  => 'ClubController@clubFollower',
    'as'    => 'clubFollower'
]);
//Club Activities 
Route::get('club/settings',[
    'uses'  => 'ClubController@clubSettings',
    'as'    => 'clubSettings'
]);

Route::post('club/update-settings',[
    'uses'  => 'ClubController@clubDetailsUpdate',
    'as'    => 'clubDetailsUpdate'
]);
 
 //Admin panel login/register routes
Route::get('control-panel/admin-login',[
    'uses'  => 'FrontController@adminLogin',
    'as'    => 'adminLogin'
]);
 
Route::post('control-panel/confirmAdminLogin',[
    'uses'  => 'FrontController@confirmAdminLogin',
    'as'    => 'confirmAdminLogin'
]);
 
Route::post('control-panel/admin/confirmRegister',[
    'uses'  => 'FrontController@confirmSuperAdminRegister',
    'as'    => 'confirmSuperAdminRegister'
]);
//Admin panel routes

Route::get('control-panel/admin/serverConfig',[
    'uses'  => 'AdminSystemManageController@serverConfig',
    'as'    => 'serverConfig'
]);
 
Route::post('control-panel/admin/saveConfig',[
    'uses'  => 'AdminPanelController@saveConfig',
    'as'    => 'saveConfig'
]);

Route::get('control-panel/admin/home',[
    'uses'  => 'AdminViewController@AdminHome',
    'as'    => 'AdminHome'
]);
 
Route::get('control-panel/admin/profile',[
    'uses'  => 'AdminViewController@adminProfile',
    'as'    => 'adminProfile'
]);
 
Route::post('control-panel/admin/profile/update',[
    'uses'  => 'AdminPanelController@updateAdmin',
    'as'    => 'updateAdmin'
]);
 
Route::post('control-panel/admin/profile/passUpdate',[
    'uses'  => 'AdminPanelController@updateAdminPass',
    'as'    => 'updateAdminPass'
]);
//Deposit routes 
Route::get('control-panel/admin/pendingDeposit',[
    'uses'  => 'AdminViewController@pendingDeposit',
    'as'    => 'pendingDeposit'
]);
 
Route::get('control-panel/admin/paidDeposit',[
    'uses'  => 'AdminViewController@paidDeposit',
    'as'    => 'paidDeposit'
]);
 
Route::get('control-panel/admin/unpaidDeposit',[
    'uses'  => 'AdminViewController@unpaidDeposit',
    'as'    => 'unpaidDeposit'
]);
 
Route::get('control-panel/admin/acceptDeposit/{id}',[
    'uses'  => 'AdminPanelController@acceptDeposit',
    'as'    => 'acceptDeposit'
]);
 
Route::get('control-panel/admin/rejectDeposit/{id}',[
    'uses'  => 'AdminPanelController@rejectDeposit',
    'as'    => 'rejectDeposit'
]); 
 
Route::get('control-panel/admin/returnDeposit/{id}',[
    'uses'  => 'AdminPanelController@returnDeposit',
    'as'    => 'returnDeposit'
]);
 
Route::get('control-panel/admin/refundDeposit/{id}',[
    'uses'  => 'AdminPanelController@refundDeposit',
    'as'    => 'refundDeposit'
]);

//Withdrawal routes
Route::get('control-panel/admin/checkUserStmt/{id}',[
    'uses'  => 'AdminViewController@checkUserStmt',
    'as'    => 'checkUserStmt'
]);
 
Route::get('control-panel/admin/pendingWithdrawal',[
    'uses'  => 'AdminViewController@pendingWithdrawal',
    'as'    => 'pendingWithdrawal'
]);

Route::get('control-panel/admin/paidWithdrawal',[
    'uses'  => 'AdminViewController@paidWithdrawal',
    'as'    => 'paidWithdrawal'
]);

Route::get('control-panel/admin/unpaidWithdrawal',[
    'uses'  => 'AdminViewController@unpaidWithdrawal',
    'as'    => 'unpaidWithdrawal'
]);
 
Route::get('control-panel/admin/processWithdrawRequest',[
    'uses'  => 'AdminViewController@processWithdrawRequest',
    'as'    => 'processWithdrawRequest'
]);
 
Route::get('control-panel/admin/acceptWithdrawal/{id}',[
    'uses'  => 'AdminViewController@acceptWithdrawal',
    'as'    => 'acceptWithdrawal'
]); 
 
Route::post('control-panel/admin/confirmWithdrawal',[
    'uses'  => 'AdminPanelController@confirmWithdrawal',
    'as'    => 'confirmWithdrawal'
]); 
 
Route::get('control-panel/admin/processingWithdrawal/{id}',[
    'uses'  => 'AdminPanelController@processingWithdrawal',
    'as'    => 'processingWithdrawal'
]);
 
Route::get('control-panel/admin/rejectWithdrawal/{id}',[
    'uses'  => 'AdminPanelController@rejectWithdrawal',
    'as'    => 'rejectWithdrawal'
]);
 
Route::get('control-panel/admin/sendToPendingList/{id}',[
    'uses'  => 'AdminViewController@rejToPenWithdraw',
    'as'    => 'rejToPenWithdraw'
]);

//Report routes
Route::get('control-panel/admin/customerReport',[
    'uses'  => 'AdminViewController@customerReport',
    'as'    => 'customerReport'
]); 
 
Route::post('control-panel/admin/finalCustomerReport',[
    'uses'  => 'AdminViewController@finalCustomerReport',
    'as'    => 'finalCustomerReport'
]); 
//End Reports routes

//Club Withdrawal routes
Route::get('control-panel/admin/checkClubStmt/{id}',[
    'uses'  => 'AdminViewController@checkClubStmt',
    'as'    => 'checkClubStmt'
]);
 
Route::get('control-panel/admin/clubPendingWithdraw',[
    'uses'  => 'AdminViewController@clubPendingWithdraw',
    'as'    => 'clubPendingWithdraw'
]);

Route::get('control-panel/admin/clubPaidWithdraw',[
    'uses'  => 'AdminViewController@clubPaidWithdraw',
    'as'    => 'clubPaidWithdraw'
]);

Route::get('control-panel/admin/clubUnpaidWithdraw',[
    'uses'  => 'AdminViewController@clubUnpaidWithdraw',
    'as'    => 'clubUnpaidWithdraw'
]);
 
Route::get('control-panel/admin/clubProcessWithdrawList',[
    'uses'  => 'AdminViewController@clubProcessWithdrawList',
    'as'    => 'clubProcessWithdrawList'
]);
 
Route::get('control-panel/admin/clubAcceptWithdraw/{id}',[
    'uses'  => 'AdminViewController@clubAcceptWithdraw',
    'as'    => 'clubAcceptWithdraw'
]); 
 
Route::post('control-panel/admin/clubConfirmWithdraw',[
    'uses'  => 'AdminPanelController@clubConfirmWithdraw',
    'as'    => 'clubConfirmWithdraw'
]); 
 
Route::get('control-panel/admin/clubProcessWithdraw/{id}',[
    'uses'  => 'AdminPanelController@clubProcessWithdraw',
    'as'    => 'clubProcessWithdraw'
]);
 
Route::get('control-panel/admin/clubRejectWithdraw/{id}',[
    'uses'  => 'AdminPanelController@clubRejectWithdraw',
    'as'    => 'clubRejectWithdraw'
]);

//User controller routes
 
Route::get('control-panel/admin/activeUser',[
    'uses'  => 'AdminViewController@activeUser',
    'as'    => 'activeUser'
]);
 
Route::get('control-panel/admin/searchUser',[
    'uses'  => 'AdminViewController@searchUser',
    'as'    => 'searchUser'
]);
 
Route::post('control-panel/admin/user/single/result/',[
    'uses'  => 'AdminViewController@singleUser',
    'as'    => 'singleUser'
]);
 
Route::get('control-panel/admin/bannedUser',[
    'uses'  => 'AdminViewController@bannedUser',
    'as'    => 'bannedUser'
]);
 
Route::get('control-panel/admin/editUser/{id}',[
    'uses'  => 'AdminViewController@editUser',
    'as'    => 'editUser'
]);
 
Route::post('control-panel/admin/updateUser',[
    'uses'  => 'AdminPanelController@updateUser',
    'as'    => 'updateUser'
]);
 
Route::get('control-panel/admin/changePassword/{id}',[
    'uses'  => 'AdminViewController@changePassword',
    'as'    => 'changePassword'
]);
 
Route::get('control-panel/admin/a2cTransfer/{id}',[
    'uses'  => 'AdminViewController@a2cTransfer',
    'as'    => 'a2cTransfer'
]);
 
Route::get('control-panel/admin/a2aTransfer/{id}',[
    'uses'  => 'AdminViewController@a2aTransfer',
    'as'    => 'a2aTransfer'
]);
 
Route::post('control-panel/admin/confirmA2CTransfer',[
    'uses'  => 'AdminPanelController@confirmA2CTransfer',
    'as'    => 'confirmA2CTransfer'
]);
 
Route::post('control-panel/admin/confirmA2ATransfer',[
    'uses'  => 'AdminPanelController@confirmA2ATransfer',
    'as'    => 'confirmA2ATransfer'
]);
 
Route::post('control-panel/admin/changeUserPass',[
    'uses'  => 'AdminPanelController@changeUserPass',
    'as'    => 'changeUserPass'
]);
 
Route::get('control-panel/admin/bannedStatus/{id}',[
    'uses'  => 'AdminViewController@bannedStatus',
    'as'    => 'bannedStatus'
]);
 
Route::get('control-panel/admin/activeStatus/{id}',[
    'uses'  => 'AdminViewController@activeStatus',
    'as'    => 'activeStatus'
]);
 
Route::get('control-panel/admin/deleteUser/{id}',[
    'uses'  => 'AdminViewController@delUser',
    'as'    => 'delUser'
]);

//Category controller route
Route::get('control-panel/admin/categoryList',[
    'uses'  => 'AdminViewController@categoryList',
    'as'    => 'categoryList'
]);
 
Route::get('control-panel/admin/newCategory',[
    'uses'  => 'AdminViewController@newCategory',
    'as'    => 'newCategory'
]);
 
Route::post('control-panel/admin/saveCategory',[
    'uses'  => 'AdminPanelController@saveCategory',
    'as'    => 'saveCategory'
]);
 
Route::get('control-panel/admin/editCategory/{id}',[
    'uses'  => 'AdminViewController@editCategory',
    'as'    => 'editCategory'
]);
 
Route::post('control-panel/admin/updateCategory',[
    'uses'  => 'AdminPanelController@updateCategory',
    'as'    => 'updateCategory'
]);
 
Route::get('control-panel/admin/deleteCategory/{id}',[
    'uses'  => 'AdminViewController@deleteCategory',
    'as'    => 'deleteCategory'
]);
 
 //Category controller route
Route::get('control-panel/admin/sliders',[
    'uses'  => 'AdminViewController@sliderList',
    'as'    => 'sliderList'
]);
 
Route::get('control-panel/admin/newSlider',[
    'uses'  => 'AdminViewController@newSlider',
    'as'    => 'newSlider'
]);
 
Route::post('control-panel/admin/saveSlider',[
    'uses'  => 'AdminPanelController@saveSlider',
    'as'    => 'saveSlider'
]);
 
Route::get('control-panel/admin/editSlider/{id}',[
    'uses'  => 'AdminViewController@editSlider',
    'as'    => 'editSlider'
]);
 
Route::post('control-panel/admin/updateSlider',[
    'uses'  => 'AdminPanelController@updateSlider',
    'as'    => 'updateSlider'
]);
 
Route::get('control-panel/admin/deleteSlider/{id}',[
    'uses'  => 'AdminViewController@deleteSlider',
    'as'    => 'deleteSlider'
]);

//Admin system manage controller route
Route::get('control-panel/admin/manageAdmin',[
    'uses'  => 'AdminSystemManageController@manageAdmin',
    'as'    => 'manageAdmin'
]);
 
Route::get('control-panel/admin/newAdminProfile',[
    'uses'  => 'AdminSystemManageController@newAdminProfile',
    'as'    => 'newAdminProfile'
]);
 
Route::post('control-panel/admin/saveAdminProfile',[
    'uses'  => 'AdminSystemManageController@saveAdminProfile',
    'as'    => 'saveAdminProfile'
]);
 
Route::get('control-panel/admin/editAdminProfile/{id}',[
    'uses'  => 'AdminSystemManageController@editAdminProfile',
    'as'    => 'editAdminProfile'
]);
 
Route::post('control-panel/admin/updateAdminProfile',[
    'uses'  => 'AdminSystemManageController@updateAdminProfile',
    'as'    => 'updateAdminProfile'
]);
 
Route::get('control-panel/admin/deleteAdminProfile/{id}',[
    'uses'  => 'AdminSystemManageController@deleteAdminProfile',
    'as'    => 'delAdminProfile'
]);
 
Route::get('control-panel/admin/inactiveAdminProfile/{id}',[
    'uses'  => 'AdminSystemManageController@inactiveAdminProfile',
    'as'    => 'inactiveAdminProfile'
]);
 
Route::get('control-panel/admin/activeAdminProfile/{id}',[
    'uses'  => 'AdminSystemManageController@activeAdminProfile',
    'as'    => 'activeAdminProfile'
]);
//Server coin management
 
Route::get('control-panel/admin/serverCoin',[
    'uses'  => 'AdminBalanceController@serverCoin',
    'as'    => 'serverCoin'
]);
 
Route::post('control-panel/admin/createServerCoin',[
    'uses'  => 'AdminBalanceController@createServerCoin',
    'as'    => 'createServerCoin'
]);
 
Route::get('control-panel/admin/adminCoin',[
    'uses'  => 'AdminBalanceController@adminCoin',
    'as'    => 'adminCoin'
]);
 
Route::post('control-panel/admin/createAdminCoin',[
    'uses'  => 'AdminBalanceController@createAdminCoin',
    'as'    => 'createAdminCoin'
]);

//bank chanels controller route
Route::get('control-panel/admin/manageBankChanel',[
    'uses'  => 'BankChanelController@manageBankChanel',
    'as'    => 'manageBankChanel'
]);
 
Route::get('control-panel/admin/newBankChanel',[
    'uses'  => 'BankChanelController@newBankChanel',
    'as'    => 'newBankChanel'
]);
 
Route::post('control-panel/admin/saveBankChanel',[
    'uses'  => 'BankChanelController@saveBankChanel',
    'as'    => 'saveBankChanel'
]);
 
Route::get('control-panel/admin/editBankChanel/{id}',[
    'uses'  => 'BankChanelController@editBankChanel',
    'as'    => 'editBankChanel'
]);
 
Route::post('control-panel/admin/updateBankChanel',[
    'uses'  => 'BankChanelController@updateBankChanel',
    'as'    => 'updateBankChanel'
]);
 
Route::get('control-panel/admin/deleteBankChanel/{id}',[
    'uses'  => 'BankChanelController@deleteBankChanel',
    'as'    => 'deleteBankChanel'
]);

//Teams controller route
Route::get('control-panel/admin/teamList',[
    'uses'  => 'AdminViewController@teamList',
    'as'    => 'teamList'
]);
 
Route::get('control-panel/admin/newTeam',[
    'uses'  => 'AdminViewController@newTeam',
    'as'    => 'newTeam'
]);
 
Route::post('control-panel/admin/saveTeam',[
    'uses'  => 'AdminPanelController@saveTeam',
    'as'    => 'saveTeam'
]);
 
Route::get('control-panel/admin/editTeam/{id}',[
    'uses'  => 'AdminViewController@editTeam',
    'as'    => 'editTeam'
]);
 
Route::post('control-panel/admin/updateTeam',[
    'uses'  => 'AdminPanelController@updateTeam',
    'as'    => 'updateTeam'
]);
 
Route::get('control-panel/admin/deleteTeam/{id}',[
    'uses'  => 'AdminViewController@deleteTeam',
    'as'    => 'deleteTeam'
]);

//Tournament controller route
Route::get('control-panel/admin/tournamentList',[
    'uses'  => 'AdminViewController@tournamentList',
    'as'    => 'tournamentList'
]);
 
Route::get('control-panel/admin/newTournament',[
    'uses'  => 'AdminViewController@newTournament',
    'as'    => 'newTournament'
]);
 
Route::post('control-panel/admin/saveTournament',[
    'uses'  => 'AdminPanelController@saveTournament',
    'as'    => 'saveTournament'
]);
 
Route::get('control-panel/admin/editTournament/{id}',[
    'uses'  => 'AdminViewController@editTournament',
    'as'    => 'editTournament'
]);
 
Route::post('control-panel/admin/updateTournament',[
    'uses'  => 'AdminPanelController@updateTournament',
    'as'    => 'updateTournament'
]);
 
Route::get('control-panel/admin/deleteTournament/{id}',[
    'uses'  => 'AdminViewController@deleteTournament',
    'as'    => 'deleteTournament'
]);

//Club controller route
Route::get('control-panel/admin/clubList',[
    'uses'  => 'AdminViewController@clubList',
    'as'    => 'clubList'
]);
 
Route::get('control-panel/admin/newClub',[
    'uses'  => 'AdminViewController@newClub',
    'as'    => 'newClub'
]);
 
Route::post('control-panel/admin/saveClub',[
    'uses'  => 'AdminPanelController@saveClub',
    'as'    => 'saveClub'
]);
 
Route::get('control-panel/admin/editClub/{id}',[
    'uses'  => 'AdminViewController@editClub',
    'as'    => 'editClub'
]);
 
Route::post('control-panel/admin/updateClub',[
    'uses'  => 'AdminPanelController@updateClub',
    'as'    => 'updateClub'
]);
 
Route::get('control-panel/admin/bannedClub/{id}',[
    'uses'  => 'AdminViewController@bannedClub',
    'as'    => 'bannedClub'
]);
 
Route::get('control-panel/admin/activeClub/{id}',[
    'uses'  => 'AdminViewController@activeClub',
    'as'    => 'activeClub'
]);
 
Route::get('control-panel/admin/deleteClub/{id}',[
    'uses'  => 'AdminViewController@deleteClub',
    'as'    => 'delClub'
]);


//Match creation controller route
Route::get('control-panel/admin/matchList/{catId}',[
    'uses'  => 'AdminViewController@matchList',
    'as'    => 'matchList'
]);
Route::get('control-panel/admin/finishMatchList/{catId}',[
    'uses'  => 'AdminViewController@finishMatchList',
    'as'    => 'finishMatchList'
]);
 
Route::get('control-panel/admin/newMatch',[
    'uses'  => 'AdminViewController@newMatch',
    'as'    => 'newMatch'
]);
 
 
Route::post('control-panel/admin/saveMatch',[
    'uses'  => 'AdminPanelController@saveMatch',
    'as'    => 'saveMatch'
]);
 
Route::get('control-panel/admin/editMatch/{id}',[
    'uses'  => 'AdminViewController@editMatch',
    'as'    => 'editMatch'
]);
 
Route::post('control-panel/admin/updateMatch',[
    'uses'  => 'AdminPanelController@updateMatch',
    'as'    => 'updateMatch'
]);
 
Route::get('control-panel/admin/deleteMatch/{id}',[
    'uses'  => 'EventController@deleteMatch',
    'as'    => 'deleteMatch'
]);

//BetOption controller route
Route::get('control-panel/admin/betOptions',[
    'uses'  => 'AdminViewController@betOptions',
    'as'    => 'betOptions'
]);
 
Route::get('control-panel/admin/newBetOption',[
    'uses'  => 'AdminViewController@newBetOption',
    'as'    => 'newBetOption'
]);
 
Route::post('control-panel/admin/saveBetOption',[
    'uses'  => 'AdminPanelController@saveBetOption',
    'as'    => 'saveBetOption'
]);
 
Route::get('control-panel/admin/editBetOption/{id}',[
    'uses'  => 'AdminViewController@editBetOption',
    'as'    => 'editBetOption'
]);
 
Route::post('control-panel/admin/updateBetOption',[
    'uses'  => 'AdminPanelController@updateBetOption',
    'as'    => 'updateBetOption'
]);
 
Route::get('control-panel/admin/deleteBetOption/{id}',[
    'uses'  => 'AdminViewController@deleteBetOption',
    'as'    => 'deleteBetOption'
]);
 
//BetAnswer controller route
Route::get('control-panel/admin/betAnswer',[
    'uses'  => 'AdminViewController@betAnswer',
    'as'    => 'betAnswer'
]);
 
Route::get('control-panel/admin/newBetAnswer',[
    'uses'  => 'AdminViewController@newBetAnswer',
    'as'    => 'newBetAnswer'
]);
 
Route::post('control-panel/admin/saveBetAnswer',[
    'uses'  => 'AdminPanelController@saveBetAnswer',
    'as'    => 'saveBetAnswer'
]);
 
Route::get('control-panel/admin/editBetAnswer/{id}',[
    'uses'  => 'AdminViewController@editBetAnswer',
    'as'    => 'editBetAnswer'
]);
 
Route::post('control-panel/admin/updateBetAnswer',[
    'uses'  => 'AdminPanelController@updateBetAnswer',
    'as'    => 'updateBetAnswer'
]);
 
Route::get('control-panel/admin/deleteBetAnswer/{id}',[
    'uses'  => 'AdminViewController@deleteBetAnswer',
    'as'    => 'deleteBetAnswer'
]);
 
 

 
//Match Question controller route
Route::get('control-panel/admin/match/liveRoom/{id}',[
    'uses'  => 'AdminViewController@liveRoom',
    'as'    => 'liveRoom'
]);
Route::get('control-panel/admin/match/manage/{id}',[
     'uses'  => 'AdminViewController@matchManage',
     'as'    => 'matchManage'
]);
Route::get('control-panel/admin/match/unpublishQuestion/{id}',[
    'uses'  => 'AdminViewController@unpublishQuestion',
    'as'    => 'unpublishQuestion'
]);
 
Route::get('control-panel/admin/matchBetHistory/{id}',[
    'uses'  => 'AdminViewController@matchBetHistory',
    'as'    => 'matchBetHistory'
]);
 
Route::get('control-panel/admin/profitLoss/{id}',[
    'uses'  => 'AdminViewController@profitLoss',
    'as'    => 'profitLoss'
]);
 
Route::get('control-panel/admin/questionBetHistory/{matchid}/{quesId}/{betOn}',[
    'uses'  => 'AdminViewController@questionBetHistory',
    'as'    => 'questionBetHistory'
]);
 
Route::get('control-panel/admin/returnBets/{id}',[
    'uses'  => 'AdminPanelController@returnBets',
    'as'    => 'returnBets'
]);

Route::get('control-panel/admin/betReturn/{matchId}/{qId}',[
    'uses'  => 'AdminPanelController@betReturn',
    'as'    => 'betReturn'
]);

 Route::get('control-panel/admin/liveRoom/{id}',[
     'uses'  => 'AdminViewController@liveRoom',
     'as'    => 'liveRoom'
 ]);
 
Route::get('control-panel/admin/newMatchQuestion',[
    'uses'  => 'AdminViewController@newMatchQuestion',
    'as'    => 'newMatchQuestion'
]);
 
Route::post('control-panel/admin/saveMatchQuestion',[
    'uses'  => 'AdminPanelController@saveMatchQuestion',
    'as'    => 'saveMatchQuestion'
]); 

Route::post('control-panel/admin/fixedSingleUpdate',[
    'uses'  => 'AdminPanelController@fixedSingleUpdate',
    'as'    => 'fixedSingleUpdate'
]);
 
Route::post('control-panel/admin/customQuestionUpdate',[
    'uses'  => 'AdminPanelController@customQuestionUpdate',
    'as'    => 'customQuestionUpdate'
]);
 
Route::get('control-panel/admin/deleteSingleQuestion/{id}',[
    'uses'  => 'AdminViewController@deleteSingleQuestion',
    'as'    => 'deleteSingleQuestion'
]);
 
Route::get('control-panel/admin/deleteCustomQuestion/{id}',[
    'uses'  => 'AdminViewController@deleteCustomQuestion',
    'as'    => 'deleteCustomQuestion'
]);
 
  
 
//JS get data controller route 
Route::get('control-panel/admin/getTournament/{id}',[
    'uses'  => 'AdminViewController@getTournament',
    'as'    => 'getTournament'
]); 
 
Route::get('control-panel/admin/getTeam/{id}',[
    'uses'  => 'AdminViewController@getTeam',
    'as'    => 'getTeam'
]); 
 
Route::get('control-panel/admin/getEditTeam/{id}/{teamA}/{teamB}',[
    'uses'  => 'AdminViewController@getEditTeam',
    'as'    => 'getEditTeam'
]); 
 
Route::get('control-panel/admin/getOption/{id}',[
    'uses'  => 'AdminViewController@getOption',
    'as'    => 'getOption'
]); 


Route::get('control-panel/admin/getOptionAnswer/{id}',[
    'uses'  => 'AdminViewController@getOptionAnswer',
    'as'    => 'getOptionAnswer'
]);
Route::get('control-panel/admin/getFixedOption/{id}/{qId}',[
    'uses'  => 'AdminViewController@getFixedOption',
    'as'    => 'getFixedOption'
]);


Route::get('control-panel/admin/getCustomAnswer/{id}',[
    'uses'  => 'AdminViewController@getCustomAnswer',
    'as'    => 'getCustomAnswer'
]);


Route::get('control-panel/admin/getAnswerData/{id}',[
    'uses'  => 'AdminViewController@getAnswerList',
    'as'    => 'getAnswerList'
]); 

Route::get('control-panel/admin/getMatchAnswerData/{id}',[
    'uses'  => 'AdminViewController@getMatchAnswerList',
    'as'    => 'getMatchAnswerList'
]); 


